#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Sprite sprite;
Texture textura;
float alto, ancho;

int main() {

    textura.loadFromFile("fondo.jpg");
    sprite.setTexture(textura);
    alto = 800.0 / textura.getSize().x;
    ancho = 600.0 / textura.getSize().y;
    sprite.setScale(alto, ancho);

    RenderWindow Ventana(VideoMode(800, 600), "Fondo");

    while (Ventana.isOpen()) {
        Ventana.clear();

        Ventana.draw(sprite);

        Ventana.display();
    }

    return 0;
}
